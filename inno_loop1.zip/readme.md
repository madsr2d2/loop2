# How do I change the information in the template?
Setup/Statics.tex

# Where can I suggest changes?
latex-support@student.dtu.dk

# Where can I go for help?
Check http://latex.dtu.dk/ for open office hours or send your question via email (latex-support@student.dtu.dk) or Facebook messenger (https://www.facebook.com/DTULatex/)

---
Last updated 07/02/2022 by s164419@student.dtu.dk